﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using VetManager.ViewModel.BaseClass;

namespace VetManager.ViewModel
{
    class Owners : PropertyChanger
    {
        private MainViewModel mainVm;
        public ICommand BackToChoiceCommand { get; set; }

        public Owners(MainViewModel mainVm)
        {
            this.mainVm = mainVm;
            BackToChoiceCommand = new RelayCommand(BackToChoice, CanBackToChoice);
        }

        private bool CanBackToChoice(object obj)
        {
            return true;
        }

        private void BackToChoice(object obj)
        {
            mainVm.CurrentView = new Choice(mainVm);
        }
    }
}
