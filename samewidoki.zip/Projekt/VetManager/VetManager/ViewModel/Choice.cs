﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VetManager.ViewModel
{
    class Choice : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        //tutaj wstawicie logikę wyboru odpowiedniego okna i przechodznia do wybranych widoków
    }
}
